Emulators menu (one entry per system, listed in file-name order).
01-07 open our ROM list on e:\GAME\<folder> and start the ROM in the stock emulator:
   name=...   picker=e:\GAME\<folder>   ext=<extensions, ; between>
08-11 start our own emulators:   name=...   app=application://<app>
To add or change an entry, edit or copy one of these files. Delete a file to remove the entry.
