Media category. Each entry opens the stock file browser in a media mode (the same "mode" numbers the stock home screen uses):
 FM Radio and Voice Recorder = launch those apps directly.
 Movies = mode 3, Music = mode 2, Photos = mode 1, E-Books = mode 5.
If one opens the wrong browser, change the mode=N number in its .ini (try 0-5). Mode 4 is the game browser; mode 0 is the plain file browser.
