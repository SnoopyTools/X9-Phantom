X9 PHANTOM - SD RESTORE v1 - 23 Nov 2026 (gremlin247)
=====================================================
Custom launcher + emulators for the X9 Black Hawk handheld (Allwinner F1C100s/F1C200s, Melis OS).
One version of each file. Everything works except the Commodore 64, which is still work in progress.
  D\ = system partition (E: on your PC)      E\ = games partition (F: on your PC: GAME folders + 2 test files)

APPS (D\apps)
  home.axf        X9 Phantom launcher r69: smooth font, our game list for the stock emulators, volume bar,
                  menu sounds (click=0 in F:\x9_launcher.cfg turns them off), power switch
  x9_sms2.axf     Master System   build 14  (PicoDrive)
  x9_doom2.axf    Doom            build 2   (doomgeneric)
  x9_amiga.axf    Amiga           build 4   (UAE4ALL)
  x9_zx.axf       ZX Spectrum     build 11  (Fuse)
  x9_a2600.axf    Atari 2600      build 2   (z26)
  x9_c64.axf      Commodore 64    build 1   (Teensy64 + reSID)  - WORK IN PROGRESS
  explorer.axf, theme.bin, skins, mod\desktop.mod   (File Browser, from the original firmware, patched)
  desktop\        one .desktop file per app

EMULATORS MENU (D\Menu\Emulators)
  01 NES  02 SNES  03 Mega Drive  04 Game Boy  05 Game Boy Color  06 GBA  07 MAME   (X9's own emulators)
  08 Master System  09 Doom  10 Amiga  11 ZX Spectrum  12 Atari 2600  13 Commodore 64   (ours)

GAME FOLDERS (games partition)
  FC (NES)  SFC  MD  GB  GBC  GBA  MAME  SMS  DOOM  AMIGA  ZX  A2600  C64
  You supply: ROMs/games, DOOM1.WAD, kick.rom (Amiga), kernal.rom + basic.rom + chargen.rom (C64).

TIDY AN EXISTING CARD
  1. On E: delete everything inside Menu\Emulators.
  2. Copy D\ contents over E: (replace).  Copy E\GAME over F:\GAME (adds the new folders).
  3. Optional: delete apps\x9_sms.axf, apps\x9_doom.axf and their .desktop files (no longer used).
  4. Eject safely and reboot (needed once for the new Atari 2600 and C64 apps).

RESTORE A FRESH CARD
  1. Put the original firmware file system on the card (from your SD image).
  2. Copy D\ over the system partition (E:), E\ over the games partition (F:).
  3. Copy your games, kick.rom, C64 ROMs, WADs and saves back. Eject safely, reboot.

NOT IN IT: the original firmware (drv, mod, stock emulators game_*.axf), your game_sms.axf, ROMs and BIOS files.
SOURCE: source\ has every program's source (GPL parts: Fuse, PicoDrive, UAE4ALL, z26, Teensy64, reSID, doomgeneric).
